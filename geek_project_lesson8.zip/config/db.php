<?php

return [
    //  Настройки базы данных
    'db' => [
        'user' => 'root',
        'password' => '',
        'host' => 'localhost',
        'database' => 'geek_project',
    ]
];