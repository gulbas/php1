<?php

// поключаем конфигурации приложения
require '../../engine/core.php';

// выводим список (БД)
function routeIndex()
{
    if (!isAdmin()) {
        header("Location: /");
    }

    echo render('admin/panel');
}

function routeOrderview()
{
    if (isset($_GET['change'])) {
        $id = (int)$_GET['change'];
        $getStatus = getItem("select status from `order` where id = {$id}");
        $getStatus ['status'] == 0 ? $status = 1 : $status = 0;
        $sql = "UPDATE `order` SET `status` = '$status' where id = {$id}";
        execute($sql);
    }

    $orders = getItemArray("select * from `order`");
    $users = getItemArray("select * from `users`");

    $orderEnd = [];

    foreach ($orders as $order) {
        if ($order['status'] == 0) {
            $order['status'] = "Новый";
        } else {
            $order['status'] = "Проведен";
        }
        foreach ($users as $user) {
            if ($order['user_id'] == $user['id']) {
                $order['user_id'] = $user['name'];
            }
        }
        array_push($orderEnd, $order);
    }

    echo render('admin/order', [
        'orders' => $orderEnd
    ]);
}


function routeProducts()
{
    if (isset($_GET['delete'])) {
        $id = $_GET['delete'];
        $id = (int)$id;
        $getGood = getItem("SELECT * FROM `product` WHERE  `id` = {$id}");
        execute("DELETE FROM  product WHERE id = {$id}");
        unlink("../img/goods/big/{$getGood['image']}");
        unlink("../img/goods/small/{$getGood['image']}");
    }

    $getProduct = getItemArray("select * from `product`");
    $categories = getItemArray("select * from `category`");

    $products = [];

    foreach ($getProduct as $product) {
        foreach ($categories as $category) {
            $product['category_id'] == $category['id'] ? $product['category_id'] = $category['name'] : 0;
        }
        array_push($products, $product);
    }

    echo render('admin/products', [
        'products' => $products
    ]);
}


// запуск маршрутизации
route();