<?php

$title = 'Страница не найдена!';

?>

<h1><?= $title ?></h1>

<p>
    Ooooops!
</p>