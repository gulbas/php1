<h1 class="text-center pt-5 display-4">GeekProject <code>v0.1</code></h1>

<ul class="list-group mt-5">
    <li class="list-group-item">Генерация шаблонов с разными макетами</li>
    <li class="list-group-item">Аутентификация пользователей</li>
    <li class="list-group-item">Авторизация пользователей (права доступа)</li>
    <li class="list-group-item">Создание/удаление отзывов</li>
    <li class="list-group-item">Автоматическая маршрутизация</li>
    <li class="list-group-item">Просмотр каталога товаров</li>
    <li class="list-group-item">Поддержка AJAX запросов (JSON ответы)</li>
    <li class="list-group-item">Добавление в корзину</li>
    <li class="list-group-item">Оформление заказа</li>
</ul>