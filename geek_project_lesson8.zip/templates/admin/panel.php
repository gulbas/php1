<h1>Панель администратора</h1>

<div class="row mt-5">
    <div class="col-4">
        <div class="list-group" id="list-tab" role="tablist">
            <a class="list-group-item list-group-item-action" href="?action=orderview">Заказы</a>
            <a class="list-group-item list-group-item-action" href="?action=products">Управление товарами</a>
        </div>
    </div>
</div>